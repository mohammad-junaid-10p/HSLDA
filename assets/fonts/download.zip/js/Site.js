﻿// Namespace
var site = (function () {
    return {};
})();

site.Global = (function () {
    var init = function () {
        // Prevents phishing attack that exploits windows opened using target="_blank". 
        $('a[target=_blank]').attr('rel', 'noopener noreferrer');

       // Call functions required for initialization here
        $('#nav-login').attr('href', window.location.origin + "/login?ReturnUrl=" + window.location.href);
    };
    var isDesktop = function () {
        return $(window).innerWidth() > 1024;
    };
    var isTablet = function () {
        return $(window).innerWidth() < 1024;
    };
    var isMobile = function () {
        return $(window).innerWidth() < 768;
    };

    return {
        init: init, 
        isDesktop: isDesktop,
        isTablet: isTablet,
        isMobile: isMobile
    };
})();
site.Curriculum = (function () {
    var init = function () {

        $(".curriculum .btn-link a").click(function (e) {
            e.stopPropagation();
        });
    };

    return {
        init: init
    };
})();
site.RTEAccordionTool = (function () {
    var init = function () {

        $('.accordion-text').parent().addClass('accordion-title');
        $('<i class="fas fa-arrow-down"></i><i class="fas fa-arrow-up"></i>').insertBefore('.accordion-title');

        $('.accordion-title').click(function () {
            if (!$(this).hasClass('opened')) {
                $(this).children('.accordion-content').slideDown(), $(this).addClass('opened');
                $(this).prevAll().eq(1).hide(), $(this).prevAll().eq(0).show();
            }
            else {
                $(this).children('.accordion-content').slideUp(), $(this).removeClass('opened');
                $(this).prevAll().eq(1).show(), $(this).prevAll().eq(0).hide();
            }
           
        });
   
    };
    
    return {
        init: init
        
    };
})();
site.SeriesBanner = (function () {
    var init = function () {

        $('.series-title-slider').slick({
            arrows: true,
            dots: false,
            slidesToShow: 3,
            slidesToScroll: 1
        });

    };

    return {
        init: init

    };
})();
site.Nav = (function () {
    var init = function () {

        $('#nav > ul > li:not(.has-drop):last-of-type a').addClass('btn').addClass('btn-reliable');
    };

    return {
        init: init

    };
})();
site.ShareLinks = (function () {
    var init = function () {
        var clipboard = new ClipboardJS('.copy-link');
        $('[data-toggle="popover"]').popover();
        $('[data-toggle="popover"]').on('shown.bs.popover', function () {
            setTimeout(function () {
                $('[data-toggle="popover"]').popover('hide');
            }, 5000);
        });        

        $('.fb-link').click(function (e) {
            e.preventDefault();
            
            window.open('https://www.facebook.com/sharer/sharer.php?u=' + $(this).data('url') + '&amp;display=popup&amp;ref=plugin', 'Facebook', 'toolbar=0,width=550,height=180');
            return false;
        });

        $('.tw-link').click(function (e) {
            e.preventDefault();
            
            window.open('https://twitter.com/intent/tweet/?text=' + $(this).data('title') + ';url=' + $(this).data('url'), 'Twitter', 'toolbar=no,width=550,height=450');
            return false;
        });

        $('.copy-link').click(function (e) {
            e.preventDefault();
        });
    };

    return {
        init: init

    };
})();
site.Categories = (function () {
    var init = function () {

        $('.more').click(function (e) {
            e.preventDefault();

            $('.more').hide();
            $('.extra-taxons').show();
        });
    };

    return {
        init: init

    };
})();

